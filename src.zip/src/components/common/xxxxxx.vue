<template>
	<div id="menu" :class="{'active': active}" @click="main($event)">
	</div>
</template>

<script>
	import {
		menusAuth
	} from '@/config/getData'

	import {
		MENU_STATE
	} from '@/store/mutation-types'

	export default {
		name: 'MenuUi',
		components: { //组件
		},
		data() { //数据
			return {
				icon: 'home',
				list: [],
				data: {},
				searchKey: ""
			}
		},
		computed: { //计算属性
			active () {
				return this.$store.state['menu-active'];
			},
			menuIcon () {
				return this.active ? ['fas','search'] : ['fas','bars'];
			}
		},
		methods: { //方法
			main (e) {
				this.stopPropagation(e);
				this.$store.commit(MENU_STATE, true);
			},
		},
		watch: {
			'searchKey' (nv, ov) {
				if (nv == ov) {
					return;
				}
				this.search();
			}
		},
		beforeCreate: function() {//创建前，属性计算之前
			this.$store.commit('LOAD_CREATE');
		},
		created: function() {//属性已有，结构未渲染
		},
		beforeMount: function() {//模板挂载前
		},
		mounted: function() {//模板挂载后
			this.$store.commit('LOAD_DESTORY');
		},
		beforeUpdate: function() {//组件更新前
		},
		updated: function() {//组件更新后
		},
		beforeDestory: function() {//组件销毁前
		},
		destoryed: function() {//组件销毁后
		}
	}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
	/*@import './x.css'*/
	#menu {
		position: fixed;
		top: 0px;
		left: 0px;
		bottom: 0px;
		overflow: auto;
		margin: 0px;
		width: 900px;
		background: skyblue;
		transform: translateX(-100%) translateX(50px);
		transition: transform 1s cubic-bezier(.55, 0, .1, 1);
	}
	#menu.active {
		transform: translateX(0%);
	}

	.itemlist-enter-active,
	.itemlist-leave-active {
		transition: all 1s;
	}

	.itemlist-enter {
		opacity: 0;
		transform: scale(0.9)
	}
	.itemlist-leave-active {
		opacity: 0;
		transform: scale(1.1)
	}

	.list {
		position: absolute;
		top: 50px;
		width: 180px;
		margin: 10px;
		padding: 0px;
		overflow-x: hidden;
	}
	.list.list_0 {
		left: 10px;
	}
	.list.list_1 {
		left: 210px;
	}
	.list.list_2 {
		left: 410px;
	}
	.list.list_3 {
		left: 610px;
	}
	.list .item {
		float: left;
		width: 78px;
		height: 78px;
		background: #606266;
		margin-bottom: 10px;
		margin-right: 10px;
		border: 1px solid transparent;
		border-radius: 5px;
	}
	.list .item.hasChild {
		background: #8C939D;
		border-color: #CF9236;
	}
	.list .item .icon {
		width: 80px;
		height: 50px;
		text-align: center;
		font-size: 40px;
	}
	.list .item .title {
		text-align: center;
		font-size: 12px;
	}
</style>