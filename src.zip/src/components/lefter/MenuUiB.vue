<template>
	<div id="menu" :class="{'active': active}" @click="main($event)">
		<div class="el-col-24" @click="stopPropagation($event)">
			<el-input v-model="searchKey" placeholder="请输入内容">
				<el-button class="search" slot="append" @click="search()">
					<fa-icon :icon="menuIcon"></fa-icon>
				</el-button>
			</el-input>
		</div>
		<transition-group name="itemlist" tag="div">
			<ul :class="'el-row list list_'+k" v-for="(i,k) in list" @click="stopPropagation($event)" :key="k">
				<li class="item" v-for="(x,t) in i" @click="menuClick(x, k)" :class="{'hasChild': x.children}" :key="t">
					<div class="icon">
						<fa-icon :icon="['fas', x.icon]"></fa-icon>
					</div>
					<div class="title">
						{{x.name}}
					</div>
				</li>
			</ul>
		</transition-group>
	</div>
</template>

<script>
	import {
		menusAuth
	} from '@/config/getData'

	import {
		MENU_STATE,
		MENU_GOTO
	} from '@/store/mutation-types'

	export default {
		name: 'MenuUi',
		components: { //组件
		},
		data() { //数据
			return {
				icon: 'xxx',
				list: [],
				data: {},
				searchKey: ""
			}
		},
		computed: { //计算属性
			active () {
				return this.$store.state['menu-active'];
			},
			menuIcon () {
				return this.active ? ['fas','search'] : ['fas','bars'];
			}
		},
		methods: { //方法
			main (e) {
				this.stopPropagation(e);
				this.$store.commit(MENU_STATE, true);
			},
			stopPropagation (e) {
				e.stopPropagation();
			},
			menuClick (item, index) {
//				let att = [];
//				this.text(this.data, att);
//				console.log(JSON.stringify(att));
				if (item.children && item.children.length > 0) {
					this.list.splice(index+1, this.list.length);
					this.$nextTick(()=>{
						this.list.push(item.children);
					})
				} else {
					this.$store.commit(MENU_STATE, false);
					this.$store.commit(MENU_GOTO, item);
				}
			},
			search () {
				this.$store.commit(MENU_STATE, true);
				if (this.searchKey.replace(/\s*/g,"") === '') {
					this.list = [];
					this.list.push(this.data);
				} else {
					this.list = [];
					this.getHasKeys(0, this.data);
				}
			},
			getHasKeys (level, data) {
				let r = new RegExp(this.searchKey.replace(/\s*/g,""));
				while (this.list.length <= level){
					this.list.push([]);
				}
				if (typeof this.list[level] !== 'object') {
					this.list[level] = [];
				}
				for (let n=0; n<data.length; n+=1) {
					if (data[n].name.match(r)) {
						this.list[level].push(data[n]);
					}
					if (data[n].children && typeof data[n].children === 'object') {
						this.getHasKeys(parseInt(level)+1, data[n].children);
					}
				}
			},
			text (data, res) {
				if (typeof res !== 'object') {
					res = [];
				}
				for (let n=0; n<data.length; n+=1) {
					if (data[n].children && typeof data[n].children === 'object') {
						this.text(data[n].children, res);
					} else {
						res.push({
							path: '/'+data[n].url,
							name: data[n].url,
							meta: {
								requireAuth: true,
							},
							component: this.f(data[n].url)
						})
//						res.push("import "+this.f(data[n].url)+" from '@/components/HelloWorld'")
					}
				}
			},
			f (str) {
				return str.substring(0,1).toUpperCase()+str.substring(1);
			}
		},
		watch: {
			'searchKey' (nv, ov) {
				if (nv == ov) {
					return;
				}
				this.search();
			}
		},
		beforeCreate: function() {//创建前，属性计算之前
			this.$store.commit('LOAD_CREATE');
		},
		created: function() {//属性已有，结构未渲染
			this.$store.commit('LOAD_CREATE');
			menusAuth().then((res) => {
				if (res.code == 200) {
					this.$store.commit('LOAD_DESTORY');
					this.list = [];
					this.data = res.data;
					this.list.push(this.data);
				}
				console.log(res);
			},(err) => {
				console.log(err);
			})
		},
		beforeMount: function() {//模板挂载前
		},
		mounted: function() {//模板挂载后
			this.$store.commit('LOAD_DESTORY');
		},
		beforeUpdate: function() {//组件更新前
		},
		updated: function() {//组件更新后
		},
		beforeDestory: function() {//组件销毁前
		},
		destoryed: function() {//组件销毁后
		}
	}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
	#menu {
		position: fixed;
		z-index: 503;
		top: 0px;
		left: 0px;
		bottom: 0px;
		overflow: auto;
		margin: 0px;
		width: 48.6rem;
		background: #273A5B;
		border-right: 1px solid #1E1E1E;
		transform: translateX(-100%) translateX(52px);
		transition: transform 1s cubic-bezier(.55, 0, .1, 1);
	}
	#menu.active {
		transform: translateX(0%);
	}

	.search {
		font-size: 24px;
		font-weight: 100;
		padding-left: 14px;
		padding-right: 14px;
	}

	.itemlist-enter-active,
	.itemlist-leave-active {
		transition: all 1s;
	}

	.itemlist-enter {
		opacity: 0;
		transform: scale(0.9)
	}
	.itemlist-leave-active {
		opacity: 0;
		transform: scale(1.1)
	}

	.list {
		width: 540px;
		margin: 10px;
		padding: 0px;
	}
	/*.list.list_0 {
		left: 10px;
	}
	.list.list_1 {
		left: 210px;
	}
	.list.list_2 {
		left: 410px;
	}
	.list.list_3 {
		left: 610px;
	}*/
	.list .item {
		float: left;
		width: 78px;
		height: 78px;
		background: #606266;
		margin-bottom: 10px;
		margin-right: 10px;
		border: 1px solid transparent;
		border-radius: 5px;
	}
	.list .item.hasChild {
		background: #8C939D;
		border-color: #CF9236;
	}
	.list .item .icon {
		width: 80px;
		height: 50px;
		text-align: center;
		font-size: 40px;
	}
	.list .item .title {
		text-align: center;
		font-size: 12px;
	}
</style>