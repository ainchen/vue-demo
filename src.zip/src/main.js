// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
//import resource from './resource';
import Vue from 'vue';

//
import ElementUI from 'element-ui';
Vue.use(ElementUI);
import 'element-ui/lib/theme-chalk/index.css';

//fontawesome
import fontawesome from '@fortawesome/fontawesome';
import {FontAwesomeIcon} from '@fortawesome/vue-fontawesome';
import solid from '@fortawesome/fontawesome-free-solid';
import regular from '@fortawesome/fontawesome-free-regular';
import brands from '@fortawesome/fontawesome-free-brands';
import { dom } from '@fortawesome/fontawesome-svg-core'
fontawesome.library.add(solid);
fontawesome.library.add(regular);
fontawesome.library.add(brands);
dom.watch();
Vue.component('fa-icon', FontAwesomeIcon);

//echarts
import echarts from 'echarts'
Vue.prototype.$echarts = echarts;

//filters
import * as filters from './config/filters'
Object.keys(filters).forEach(k => {
  Vue.filter(k, filters[k]);
})

import "@/style/css"; // css
import App from '@/App';
import router from '@/router';
import store from '@/store';
import {
	LOGIN,
	MENU_GOTO,
	LOAD_CREATE,
	LOAD_DESTORY
} from './store/mutation-types'
store.commit(LOAD_DESTORY, 0);
store.commit(LOAD_CREATE);

import rem from './config/rem';

Vue.config.productionTip = false

/* eslint-disable no-new login_remove*/
new Vue({
	el: '#app',
	router,
	store,
	components: {
		App
	},
	template: '<App/>',
	created: function() {
		store.commit(LOGIN);
		if (store.state['menu-history'].length > 0) {
			store.commit(MENU_GOTO,store.state['menu-history'][0]);
		} else {
			router.push({
				name: 'workspace'
			})
		}
	},
	mounted: function() {
		this.$nextTick(()=>{
			store.commit(LOAD_DESTORY);
		});
	},
})
