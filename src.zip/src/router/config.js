const findParent = (list, name) => {
	if (!list || list.length <= 0) {
		return ;
	}
	let r;
	for (var n=0; n<list.length; n+=1) {
		if (list[n].name == name) {
			return list[n];
		} else {
			r = findParent(list[n].children, name);
			if (r) {
				return r;
			}
		}
	}
	return ;
}
/**
 * childList: {parentName, route}
 *
 *
 */
export const setRoutes = (routeMain, childList) => {
	for (var n=0; n<childList.length; n+=1) {
		let p = findParent(routeMain, childList[n].parentName);
		if (p && childList[n].route) {
			if (p.children && p.children.length > 0) {
				p.children = p.children.concat(childList[n].route);
			} else {
				p.children = childList[n].route;
			}
		}

	}
	return routeMain;
}
