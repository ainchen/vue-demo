import Vue from 'vue'
import Router from 'vue-router'
import store from '@/store';
import {
	LOAD_DESTORY
} from '@/store/mutation-types'

import {setRoutes} from './config';
import w_routes from './workspace'

import Login from '@/pages/login/Login'
import Workspace from '@/pages/workspace/Workspace'

import Error from '@/pages/404/Error'

Vue.use(Router)

let routes = [
	{
		path: '/',
		redirect: {
			name: 'login'
		}
	},
	{
		path: '/login',
		name: 'login',
		meta: {
			requireAuth: false,
		},
		component: Login
	},
	{
		path: '/workspace',
		name: 'workspace',
		meta: {
			requireAuth: true,
		},
		component: Workspace
	},
	{
		path: '*',
		meta: {
			requireAuth: false,
		},
		component: Error
	}
];

setRoutes(routes, [{
	parentName: w_routes.parent,
	route: w_routes.routes
}])
console.log(routes);
const router = new Router({
	mode: 'history',
	routes: routes
})

router.beforeEach(function(to, from, next) {
	if (to.matched.length <= 0) {
		store.commit(LOAD_DESTORY, 0);
		next(' ');
	}
	if(store.getters.isLogin(to.meta.requireAuth)) { // 是否存在登录信息
		next();
	} else {
		store.commit(LOAD_DESTORY, 0);
		next({
			name: 'login'
		})
	}
})

export default router;