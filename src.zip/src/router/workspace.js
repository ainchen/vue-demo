const Test = () => import ('@/pages/test/Test')

const OlCategory = () => import ('@/pages/workspace/HelloWorld')
const OlCourse = () => import ('@/pages/workspace/HelloWorld')
const OlTeachingMaterial = () => import ('@/pages/workspace/HelloWorld')
const OlTeachingResources = () => import ('@/pages/workspace/HelloWorld')
const OlQuestionBank = () => import ('@/pages/workspace/HelloWorld')
const OlQuestionType = () => import ('@/pages/workspace/HelloWorld')
const OlQuestion = () => import ('@/pages/workspace/HelloWorld')
const OlPracticePaper = () => import ('@/pages/workspace/HelloWorld')
const OlExamPaper = () => import ('@/pages/workspace/HelloWorld')
const Marking = () => import ('@/pages/workspace/HelloWorld')
const EnrollPublish = () => import ('@/pages/workspace/HelloWorld')
const ExamModules = () => import ('@/pages/workspace/HelloWorld')
const EnrollApplyCheck = () => import ('@/pages/workspace/HelloWorld')
const EnrollAskCheck = () => import ('@/pages/workspace/HelloWorld')
const CoursePlan = () => import ('@/pages/workspace/HelloWorld')
const CourseScheduling = () => import ('@/pages/workspace/HelloWorld')
const Timetable = () => import ('@/pages/workspace/HelloWorld')
const TimeTable = () => import ('@/pages/workspace/HelloWorld')
const Course = () => import ('@/pages/workspace/HelloWorld')
const Student = () => import ('@/pages/workspace/HelloWorld')
const Program = () => import ('@/pages/workspace/HelloWorld')
const ExamEnroll = () => import ('@/pages/workspace/HelloWorld')
const SchoolNotice = () => import ('@/pages/workspace/HelloWorld')
const Dormitory = () => import ('@/pages/workspace/HelloWorld')
const FaultClassifcation = () => import ('@/pages/workspace/HelloWorld')
const FaultInfo = () => import ('@/pages/workspace/HelloWorld')
const Msg = () => import ('@/pages/workspace/HelloWorld')
const Self = () => import ('@/pages/workspace/HelloWorld')
const BaseSetting = () => import ('@/pages/workspace/HelloWorld')
const School = () => import ('@/pages/workspace/HelloWorld')
const Campus = () => import ('@/pages/workspace/HelloWorld')
const TermDate = () => import ('@/pages/workspace/HelloWorld')
const Major = () => import ('@/pages/workspace/HelloWorld')
const OrgAdministration = () => import ('@/pages/workspace/HelloWorld')
const OrgFinancial = () => import ('@/pages/workspace/HelloWorld')
const OrgProject = () => import ('@/pages/workspace/HelloWorld')
const OrgLearning = () => import ('@/pages/workspace/HelloWorld')
const Staff = () => import ('@/pages/workspace/HelloWorld')
const OrgClass = () => import ('@/pages/workspace/HelloWorld')
const Flow = () => import ('@/pages/workspace/HelloWorld')
const UserManage = () => import ('@/pages/workspace/HelloWorld')
const RoleManage = () => import ('@/pages/workspace/HelloWorld')
const OperationManage = () => import ('@/pages/workspace/HelloWorld')
const MenuManage = () => import ('@/pages/workspace/HelloWorld')
const ProApply = () => import ('@/pages/workspace/HelloWorld')
const LabManager = () => import ('@/pages/workspace/HelloWorld')
const StationManagement = () => import ('@/pages/workspace/HelloWorld')
const SupplierManagement = () => import ('@/pages/workspace/HelloWorld')
const LabDevice = () => import ('@/pages/workspace/HelloWorld')
const LabMaterial = () => import ('@/pages/workspace/HelloWorld')
const VLabManagement = () => import ('@/pages/workspace/HelloWorld')
const CourseManagement = () => import ('@/pages/workspace/HelloWorld')
const Subject = () => import ('@/pages/workspace/HelloWorld')
const SignupManagement = () => import ('@/pages/workspace/HelloWorld')
const ExperimentRecord = () => import ('@/pages/workspace/HelloWorld')
const Preview = () => import ('@/pages/workspace/HelloWorld')
const Reward = () => import ('@/pages/workspace/HelloWorld')
const Sche = () => import ('@/pages/workspace/HelloWorld')
const InnovationConf = () => import ('@/pages/workspace/HelloWorld')
const InnovationProcess = () => import ('@/pages/workspace/HelloWorld')
const Innovation = () => import ('@/pages/workspace/HelloWorld')
const InnovationEndup = () => import ('@/pages/workspace/HelloWorld')
const Thesis = () => import ('@/pages/workspace/HelloWorld')
const Judges = () => import ('@/pages/workspace/HelloWorld')
const GdpProcess = () => import ('@/pages/workspace/HelloWorld')
const ThesisEnroll = () => import ('@/pages/workspace/HelloWorld')
const Topic = () => import ('@/pages/workspace/HelloWorld')
const GdpRecord = () => import ('@/pages/workspace/HelloWorld')
const InternshipBase = () => import ('@/pages/workspace/HelloWorld')
const Internship = () => import ('@/pages/workspace/HelloWorld')
const SignIn = () => import ('@/pages/workspace/HelloWorld')
const EduData = () => import ('@/pages/workspace/HelloWorld')
const AppointNotes = () => import ('@/pages/workspace/HelloWorld')
const Appoint = () => import ('@/pages/workspace/HelloWorld')
const Appointment = () => import ('@/pages/workspace/HelloWorld')
const ComputerUse = () => import ('@/pages/workspace/HelloWorld')
const Console = () => import ('@/pages/workspace/HelloWorld')
const RealtimeEnergy = () => import ('@/pages/workspace/HelloWorld')
const Energy = () => import ('@/pages/workspace/HelloWorld')
const ClassApply = () => import ('@/pages/workspace/HelloWorld')
const ClassExAp = () => import ('@/pages/workspace/HelloWorld')
const AlarmSet = () => import ('@/pages/workspace/HelloWorld')
const AlarmMonitor = () => import ('@/pages/workspace/HelloWorld')
const Polling = () => import ('@/pages/workspace/HelloWorld')
const Warning = () => import ('@/pages/workspace/HelloWorld')
const FaultInquiry = () => import ('@/pages/workspace/HelloWorld')
const Supervisory = () => import ('@/pages/workspace/HelloWorld')
const AssetImport = () => import ('@/pages/workspace/HelloWorld')
const AssetMaint = () => import ('@/pages/workspace/HelloWorld')
const FaceResource = () => import ('@/pages/workspace/HelloWorld')
const AutoSign = () => import ('@/pages/workspace/HelloWorld')
const SignSetting = () => import ('@/pages/workspace/HelloWorld')
const Execute = () => import ('@/pages/workspace/HelloWorld')
const PeopleCounting = () => import ('@/pages/workspace/HelloWorld')
const FaceDatabase = () => import ('@/pages/workspace/HelloWorld')
const FacePreview = () => import ('@/pages/workspace/HelloWorld')
const Infomation = () => import ('@/pages/workspace/HelloWorld')
const FailureRate = () => import ('@/pages/workspace/HelloWorld')
const UsedLong = () => import ('@/pages/workspace/HelloWorld')
const UtilizationRate = () => import ('@/pages/workspace/HelloWorld')
const Device = () => import ('@/pages/workspace/HelloWorld')
const Computer = () => import ('@/pages/workspace/HelloWorld')
const TeachEquipment = () => import ('@/pages/workspace/HelloWorld')
const Camera = () => import ('@/pages/workspace/HelloWorld')
const Card = () => import ('@/pages/workspace/HelloWorld')
const Gateway = () => import ('@/pages/workspace/HelloWorld')
const HeaderConfig = () => import ('@/pages/workspace/HelloWorld')
const Consoleset = () => import ('@/pages/workspace/HelloWorld')
const TimedTask = () => import ('@/pages/workspace/HelloWorld')
const AccessLock = () => import ('@/pages/workspace/HelloWorld')
const AccessLog = () => import ('@/pages/workspace/HelloWorld')
const PunchCard = () => import ('@/pages/workspace/HelloWorld')
const AccessUserNum = () => import ('@/pages/workspace/HelloWorld')

const routes = [{
	"path": "/olCategory",
	"name": "olCategory",
	"meta": {
		"requireAuth": true
	},
	"component": OlCategory
}, {
	"path": "/olCourse",
	"name": "olCourse",
	"meta": {
		"requireAuth": true
	},
	"component": OlCourse
}, {
	"path": "/olTeachingMaterial",
	"name": "olTeachingMaterial",
	"meta": {
		"requireAuth": true
	},
	"component": OlTeachingMaterial
}, {
	"path": "/olTeachingResources",
	"name": "olTeachingResources",
	"meta": {
		"requireAuth": true
	},
	"component": OlTeachingResources
}, {
	"path": "/olQuestionBank",
	"name": "olQuestionBank",
	"meta": {
		"requireAuth": true
	},
	"component": OlQuestionBank
}, {
	"path": "/olQuestionType",
	"name": "olQuestionType",
	"meta": {
		"requireAuth": true
	},
	"component": OlQuestionType
}, {
	"path": "/olQuestion",
	"name": "olQuestion",
	"meta": {
		"requireAuth": true
	},
	"component": OlQuestion
}, {
	"path": "/olPracticePaper",
	"name": "olPracticePaper",
	"meta": {
		"requireAuth": true
	},
	"component": OlPracticePaper
}, {
	"path": "/olExamPaper",
	"name": "olExamPaper",
	"meta": {
		"requireAuth": true
	},
	"component": OlExamPaper
}, {
	"path": "/marking",
	"name": "marking",
	"meta": {
		"requireAuth": true
	},
	"component": Marking
}, {
	"path": "/enrollPublish",
	"name": "enrollPublish",
	"meta": {
		"requireAuth": true
	},
	"component": EnrollPublish
}, {
	"path": "/examModules",
	"name": "examModules",
	"meta": {
		"requireAuth": true
	},
	"component": ExamModules
}, {
	"path": "/enrollApplyCheck",
	"name": "enrollApplyCheck",
	"meta": {
		"requireAuth": true
	},
	"component": EnrollApplyCheck
}, {
	"path": "/enrollAskCheck",
	"name": "enrollAskCheck",
	"meta": {
		"requireAuth": true
	},
	"component": EnrollAskCheck
}, {
	"path": "/coursePlan",
	"name": "coursePlan",
	"meta": {
		"requireAuth": true
	},
	"component": CoursePlan
}, {
	"path": "/courseScheduling",
	"name": "courseScheduling",
	"meta": {
		"requireAuth": true
	},
	"component": CourseScheduling
}, {
	"path": "/timetable",
	"name": "timetable",
	"meta": {
		"requireAuth": true
	},
	"component": Timetable
}, {
	"path": "/timeTable",
	"name": "timeTable",
	"meta": {
		"requireAuth": true
	},
	"component": TimeTable
}, {
	"path": "/course",
	"name": "course",
	"meta": {
		"requireAuth": true
	},
	"component": Course
}, {
	"path": "/student",
	"name": "student",
	"meta": {
		"requireAuth": true
	},
	"component": Student
}, {
	"path": "/program",
	"name": "program",
	"meta": {
		"requireAuth": true
	},
	"component": Program
}, {
	"path": "/examEnroll",
	"name": "examEnroll",
	"meta": {
		"requireAuth": true
	},
	"component": ExamEnroll
}, {
	"path": "/schoolNotice",
	"name": "schoolNotice",
	"meta": {
		"requireAuth": true
	},
	"component": SchoolNotice
}, {
	"path": "/dormitory",
	"name": "dormitory",
	"meta": {
		"requireAuth": true
	},
	"component": Dormitory
}, {
	"path": "/faultClassifcation",
	"name": "faultClassifcation",
	"meta": {
		"requireAuth": true
	},
	"component": FaultClassifcation
}, {
	"path": "/faultInfo",
	"name": "faultInfo",
	"meta": {
		"requireAuth": true
	},
	"component": FaultInfo
}, {
	"path": "/msg",
	"name": "msg",
	"meta": {
		"requireAuth": true
	},
	"component": Msg
}, {
	"path": "/1",
	"name": "1",
	"meta": {
		"requireAuth": true
	},
	"component": Test
}, {
	"path": "/self",
	"name": "self",
	"meta": {
		"requireAuth": true
	},
	"component": Self
}, {
	"path": "/baseSetting",
	"name": "baseSetting",
	"meta": {
		"requireAuth": true
	},
	"component": BaseSetting
}, {
	"path": "/school",
	"name": "school",
	"meta": {
		"requireAuth": true
	},
	"component": School
}, {
	"path": "/campus",
	"name": "campus",
	"meta": {
		"requireAuth": true
	},
	"component": Campus
}, {
	"path": "/termDate",
	"name": "termDate",
	"meta": {
		"requireAuth": true
	},
	"component": TermDate
}, {
	"path": "/major",
	"name": "major",
	"meta": {
		"requireAuth": true
	},
	"component": Major
}, {
	"path": "/orgAdministration",
	"name": "orgAdministration",
	"meta": {
		"requireAuth": true
	},
	"component": OrgAdministration
}, {
	"path": "/orgFinancial",
	"name": "orgFinancial",
	"meta": {
		"requireAuth": true
	},
	"component": OrgFinancial
}, {
	"path": "/orgProject",
	"name": "orgProject",
	"meta": {
		"requireAuth": true
	},
	"component": OrgProject
}, {
	"path": "/orgLearning",
	"name": "orgLearning",
	"meta": {
		"requireAuth": true
	},
	"component": OrgLearning
}, {
	"path": "/staff",
	"name": "staff",
	"meta": {
		"requireAuth": true
	},
	"component": Staff
}, {
	"path": "/orgClass",
	"name": "orgClass",
	"meta": {
		"requireAuth": true
	},
	"component": OrgClass
}, {
	"path": "/flow",
	"name": "flow",
	"meta": {
		"requireAuth": true
	},
	"component": Flow
}, {
	"path": "/userManage",
	"name": "userManage",
	"meta": {
		"requireAuth": true
	},
	"component": UserManage
}, {
	"path": "/roleManage",
	"name": "roleManage",
	"meta": {
		"requireAuth": true
	},
	"component": RoleManage
}, {
	"path": "/operationManage",
	"name": "operationManage",
	"meta": {
		"requireAuth": true
	},
	"component": OperationManage
}, {
	"path": "/menuManage",
	"name": "menuManage",
	"meta": {
		"requireAuth": true
	},
	"component": MenuManage
}, {
	"path": "/proApply",
	"name": "proApply",
	"meta": {
		"requireAuth": true
	},
	"component": ProApply
}, {
	"path": "/labManager",
	"name": "labManager",
	"meta": {
		"requireAuth": true
	},
	"component": LabManager
}, {
	"path": "/stationManagement",
	"name": "stationManagement",
	"meta": {
		"requireAuth": true
	},
	"component": StationManagement
}, {
	"path": "/supplierManagement",
	"name": "supplierManagement",
	"meta": {
		"requireAuth": true
	},
	"component": SupplierManagement
}, {
	"path": "/labDevice",
	"name": "labDevice",
	"meta": {
		"requireAuth": true
	},
	"component": LabDevice
}, {
	"path": "/labMaterial",
	"name": "labMaterial",
	"meta": {
		"requireAuth": true
	},
	"component": LabMaterial
}, {
	"path": "/vLabManagement",
	"name": "vLabManagement",
	"meta": {
		"requireAuth": true
	},
	"component": VLabManagement
}, {
	"path": "/courseManagement",
	"name": "courseManagement",
	"meta": {
		"requireAuth": true
	},
	"component": CourseManagement
}, {
	"path": "/subject",
	"name": "subject",
	"meta": {
		"requireAuth": true
	},
	"component": Subject
}, {
	"path": "/signupManagement",
	"name": "signupManagement",
	"meta": {
		"requireAuth": true
	},
	"component": SignupManagement
}, {
	"path": "/experimentRecord",
	"name": "experimentRecord",
	"meta": {
		"requireAuth": true
	},
	"component": ExperimentRecord
}, {
	"path": "/preview",
	"name": "preview",
	"meta": {
		"requireAuth": true
	},
	"component": Preview
}, {
	"path": "/reward",
	"name": "reward",
	"meta": {
		"requireAuth": true
	},
	"component": Reward
}, {
	"path": "/sche",
	"name": "sche",
	"meta": {
		"requireAuth": true
	},
	"component": Sche
}, {
	"path": "/innovationConf",
	"name": "innovationConf",
	"meta": {
		"requireAuth": true
	},
	"component": InnovationConf
}, {
	"path": "/innovationProcess",
	"name": "innovationProcess",
	"meta": {
		"requireAuth": true
	},
	"component": InnovationProcess
}, {
	"path": "/innovation",
	"name": "innovation",
	"meta": {
		"requireAuth": true
	},
	"component": Innovation
}, {
	"path": "/innovationEndup",
	"name": "innovationEndup",
	"meta": {
		"requireAuth": true
	},
	"component": InnovationEndup
}, {
	"path": "/thesis",
	"name": "thesis",
	"meta": {
		"requireAuth": true
	},
	"component": Thesis
}, {
	"path": "/judges",
	"name": "judges",
	"meta": {
		"requireAuth": true
	},
	"component": Judges
}, {
	"path": "/gdpProcess",
	"name": "gdpProcess",
	"meta": {
		"requireAuth": true
	},
	"component": GdpProcess
}, {
	"path": "/thesisEnroll",
	"name": "thesisEnroll",
	"meta": {
		"requireAuth": true
	},
	"component": ThesisEnroll
}, {
	"path": "/topic",
	"name": "topic",
	"meta": {
		"requireAuth": true
	},
	"component": Topic
}, {
	"path": "/gdpRecord",
	"name": "gdpRecord",
	"meta": {
		"requireAuth": true
	},
	"component": GdpRecord
}, {
	"path": "/internshipBase",
	"name": "internshipBase",
	"meta": {
		"requireAuth": true
	},
	"component": InternshipBase
}, {
	"path": "/internship",
	"name": "internship",
	"meta": {
		"requireAuth": true
	},
	"component": Internship
}, {
	"path": "/signIn",
	"name": "signIn",
	"meta": {
		"requireAuth": true
	},
	"component": SignIn
}, {
	"path": "/eduData",
	"name": "eduData",
	"meta": {
		"requireAuth": true
	},
	"component": EduData
}, {
	"path": "/appointNotes",
	"name": "appointNotes",
	"meta": {
		"requireAuth": true
	},
	"component": AppointNotes
}, {
	"path": "/appoint",
	"name": "appoint",
	"meta": {
		"requireAuth": true
	},
	"component": Appoint
}, {
	"path": "/appointment",
	"name": "appointment",
	"meta": {
		"requireAuth": true
	},
	"component": Appointment
}, {
	"path": "/computerUse",
	"name": "computerUse",
	"meta": {
		"requireAuth": true
	},
	"component": ComputerUse
}, {
	"path": "/console",
	"name": "console",
	"meta": {
		"requireAuth": true
	},
	"component": Console
}, {
	"path": "/realtimeEnergy",
	"name": "realtimeEnergy",
	"meta": {
		"requireAuth": true
	},
	"component": RealtimeEnergy
}, {
	"path": "/energy",
	"name": "energy",
	"meta": {
		"requireAuth": true
	},
	"component": Energy
}, {
	"path": "/classApply",
	"name": "classApply",
	"meta": {
		"requireAuth": true
	},
	"component": ClassApply
}, {
	"path": "/classExAp",
	"name": "classExAp",
	"meta": {
		"requireAuth": true
	},
	"component": ClassExAp
}, {
	"path": "/alarmSet",
	"name": "alarmSet",
	"meta": {
		"requireAuth": true
	},
	"component": AlarmSet
}, {
	"path": "/alarmMonitor",
	"name": "alarmMonitor",
	"meta": {
		"requireAuth": true
	},
	"component": AlarmMonitor
}, {
	"path": "/polling",
	"name": "polling",
	"meta": {
		"requireAuth": true
	},
	"component": Polling
}, {
	"path": "/warning",
	"name": "warning",
	"meta": {
		"requireAuth": true
	},
	"component": Warning
}, {
	"path": "/faultInquiry",
	"name": "faultInquiry",
	"meta": {
		"requireAuth": true
	},
	"component": FaultInquiry
}, {
	"path": "/supervisory",
	"name": "supervisory",
	"meta": {
		"requireAuth": true
	},
	"component": Supervisory
}, {
	"path": "/assetImport",
	"name": "assetImport",
	"meta": {
		"requireAuth": true
	},
	"component": AssetImport
}, {
	"path": "/assetMaint",
	"name": "assetMaint",
	"meta": {
		"requireAuth": true
	},
	"component": AssetMaint
}, {
	"path": "/faceResource",
	"name": "faceResource",
	"meta": {
		"requireAuth": true
	},
	"component": FaceResource
}, {
	"path": "/autoSign",
	"name": "autoSign",
	"meta": {
		"requireAuth": true
	},
	"component": AutoSign
}, {
	"path": "/signSetting",
	"name": "signSetting",
	"meta": {
		"requireAuth": true
	},
	"component": SignSetting
}, {
	"path": "/execute",
	"name": "execute",
	"meta": {
		"requireAuth": true
	},
	"component": Execute
}, {
	"path": "/peopleCounting",
	"name": "peopleCounting",
	"meta": {
		"requireAuth": true
	},
	"component": PeopleCounting
}, {
	"path": "/faceDatabase",
	"name": "faceDatabase",
	"meta": {
		"requireAuth": true
	},
	"component": FaceDatabase
}, {
	"path": "/facePreview",
	"name": "facePreview",
	"meta": {
		"requireAuth": true
	},
	"component": FacePreview
}, {
	"path": "/infomation",
	"name": "infomation",
	"meta": {
		"requireAuth": true
	},
	"component": Infomation
}, {
	"path": "/failureRate",
	"name": "failureRate",
	"meta": {
		"requireAuth": true
	},
	"component": FailureRate
}, {
	"path": "/usedLong",
	"name": "usedLong",
	"meta": {
		"requireAuth": true
	},
	"component": UsedLong
}, {
	"path": "/utilizationRate",
	"name": "utilizationRate",
	"meta": {
		"requireAuth": true
	},
	"component": UtilizationRate
}, {
	"path": "/device",
	"name": "device",
	"meta": {
		"requireAuth": true
	},
	"component": Device
}, {
	"path": "/computer",
	"name": "computer",
	"meta": {
		"requireAuth": true
	},
	"component": Computer
}, {
	"path": "/teachEquipment",
	"name": "teachEquipment",
	"meta": {
		"requireAuth": true
	},
	"component": TeachEquipment
}, {
	"path": "/camera",
	"name": "camera",
	"meta": {
		"requireAuth": true
	},
	"component": Camera
}, {
	"path": "/card",
	"name": "card",
	"meta": {
		"requireAuth": true
	},
	"component": Card
}, {
	"path": "/gateway",
	"name": "gateway",
	"meta": {
		"requireAuth": true
	},
	"component": Gateway
}, {
	"path": "/headerConfig",
	"name": "headerConfig",
	"meta": {
		"requireAuth": true
	},
	"component": HeaderConfig
}, {
	"path": "/consoleset",
	"name": "consoleset",
	"meta": {
		"requireAuth": true
	},
	"component": Consoleset
}, {
	"path": "/timedTask",
	"name": "timedTask",
	"meta": {
		"requireAuth": true
	},
	"component": TimedTask
}, {
	"path": "/accessLock",
	"name": "accessLock",
	"meta": {
		"requireAuth": true
	},
	"component": AccessLock
}, {
	"path": "/accessLog",
	"name": "accessLog",
	"meta": {
		"requireAuth": true
	},
	"component": AccessLog
}, {
	"path": "/punchCard",
	"name": "punchCard",
	"meta": {
		"requireAuth": true
	},
	"component": PunchCard
}, {
	"path": "/accessUserNum",
	"name": "accessUserNum",
	"meta": {
		"requireAuth": true
	},
	"component": AccessUserNum
}];
export default {
	'parent': 'workspace',
	'routes': routes
}
