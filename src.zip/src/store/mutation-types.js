//登录
export const LOGIN = 'LOGIN'
//退出
export const EXIT = 'EXIT'
//设置活动时间
export const ACTIVE_TIME = 'ACTIVE_TIME'
//开启Loading
export const LOAD_CREATE = 'LOAD_CREATE'
//关闭Loading
export const LOAD_DESTORY = 'LOAD_DESTORY'
//修改菜单状态
export const MENU_STATE = 'MENU_STATE'
//菜单跳转
export const MENU_GOTO = 'MENU_GOTO'
