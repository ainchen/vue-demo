import {
	EXIT
} from './mutation-types'

import store from '@/store';

export default {
	isLogin: (state, getters) => (k) => {
		if (!k) {
			return true;
		} else if (state['x-token'] && state['userInfo']) {
			const d = new Date();
			console.log(d.getTime() - state['active-time'] <= 1800000)
			if (d.getTime() - state['active-time'] <= 1800000) {
				return true;
			} else {
				store.commit(EXIT);
				return false;
			}

		} else {
			return false;
		}
	},
}